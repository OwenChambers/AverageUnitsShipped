﻿Public Class frmAverageUnits
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub
    'variables for calculations
    Const DaysInAWeek As Integer = 7
    Dim currentDay As Integer = 1
    Dim totalUnits As Integer = 0
    Dim averageUnits As Double = 0
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        'Variables to hold user input
        Dim averageUnits As Double
        Dim currentUnits As Integer
        'Ensures input is valid
        If Integer.TryParse(txtUnitsPerDay.Text, currentUnits) = True Then
            'Displays next day and adds user input to list
            currentDay += 1
            If currentDay < 9 Then
                totalUnits += CInt(txtUnitsPerDay.Text)
                txtUnitsList.Text &= txtUnitsPerDay.Text & vbCrLf
                txtUnitsPerDay.Clear()
                lblDays.Text = "Day: " + CStr(currentDay)
                txtUnitsPerDay.Select()
            End If
            'Calculates average and disables user input
            If currentDay = 8 Then
                lblDays.Text = "Day: 7"
                averageUnits = totalUnits / DaysInAWeek
                lblAverageUnits.Text = "Average Units: " + CStr(Math.Round(averageUnits, 2))
                btnEnter.Enabled = False
                txtUnitsPerDay.Enabled = False
                btnReset.Select()
            End If
            'Shows an error message is user input is not validated
        Else
            MessageBox.Show("ERROR: Please enter a valid whole number.")
            txtUnitsPerDay.Clear()
        End If
    End Sub
    'resets application and all variables
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtUnitsList.Clear()
        currentDay = 1
        txtUnitsPerDay.Clear()
        txtUnitsPerDay.Select()
        lblDays.Text = "Day: 1"
        totalUnits = 0
        lblAverageUnits.Text = ""
        btnEnter.Enabled = True
        txtUnitsPerDay.Enabled = True
    End Sub
    'closes appliation
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtUnitsList_TextChanged(sender As Object, e As EventArgs) Handles txtUnitsList.TextChanged

    End Sub
End Class

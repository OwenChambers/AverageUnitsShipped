﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnits
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtUnitsPerDay = New System.Windows.Forms.TextBox()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.txtUnitsList = New System.Windows.Forms.TextBox()
        Me.lblAverageUnits = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttpUnitTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblUnits
        '
        Me.lblUnits.AutoSize = True
        Me.lblUnits.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUnits.Location = New System.Drawing.Point(68, 12)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(46, 18)
        Me.lblUnits.TabIndex = 0
        Me.lblUnits.Text = "&Units:"
        '
        'txtUnitsPerDay
        '
        Me.txtUnitsPerDay.Location = New System.Drawing.Point(115, 12)
        Me.txtUnitsPerDay.Name = "txtUnitsPerDay"
        Me.txtUnitsPerDay.Size = New System.Drawing.Size(68, 20)
        Me.txtUnitsPerDay.TabIndex = 1
        Me.ttpUnitTips.SetToolTip(Me.txtUnitsPerDay, "Enter Units")
        '
        'lblDays
        '
        Me.lblDays.AutoSize = True
        Me.lblDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDays.Location = New System.Drawing.Point(184, 12)
        Me.lblDays.Name = "lblDays"
        Me.lblDays.Size = New System.Drawing.Size(50, 18)
        Me.lblDays.TabIndex = 2
        Me.lblDays.Text = "Day: 1"
        '
        'txtUnitsList
        '
        Me.txtUnitsList.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.txtUnitsList.Location = New System.Drawing.Point(71, 38)
        Me.txtUnitsList.Multiline = True
        Me.txtUnitsList.Name = "txtUnitsList"
        Me.txtUnitsList.ReadOnly = True
        Me.txtUnitsList.Size = New System.Drawing.Size(163, 150)
        Me.txtUnitsList.TabIndex = 3
        '
        'lblAverageUnits
        '
        Me.lblAverageUnits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageUnits.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverageUnits.Location = New System.Drawing.Point(12, 191)
        Me.lblAverageUnits.Name = "lblAverageUnits"
        Me.lblAverageUnits.Size = New System.Drawing.Size(283, 30)
        Me.lblAverageUnits.TabIndex = 4
        Me.lblAverageUnits.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(12, 224)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 5
        Me.btnEnter.Text = "&Enter"
        Me.ttpUnitTips.SetToolTip(Me.btnEnter, "Add units to list and calculate average")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(115, 224)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 6
        Me.btnReset.Text = "&Reset"
        Me.ttpUnitTips.SetToolTip(Me.btnReset, "Reset application")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(220, 224)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "E&xit"
        Me.ttpUnitTips.SetToolTip(Me.btnExit, "Exit application")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmAverageUnits
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(307, 257)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblAverageUnits)
        Me.Controls.Add(Me.txtUnitsList)
        Me.Controls.Add(Me.lblDays)
        Me.Controls.Add(Me.txtUnitsPerDay)
        Me.Controls.Add(Me.lblUnits)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAverageUnits"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblUnits As Label
    Friend WithEvents txtUnitsPerDay As TextBox
    Friend WithEvents lblDays As Label
    Friend WithEvents txtUnitsList As TextBox
    Friend WithEvents lblAverageUnits As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ttpUnitTips As ToolTip
End Class
